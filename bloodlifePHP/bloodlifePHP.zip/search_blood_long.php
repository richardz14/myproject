<?php

//$server = "localhost";
//$user = "root";
//$pass = "";
//$database = "bloodlife_db";

$server = "sql208.byethost6.com";
$user = "b6_20129653";
$pass = "ap061581";
$database = "b6_20129653_bloodlife_db";

$conection = mysql_connect($server, $user, $pass);
mysql_select_db($database,$conection);

$long = $_REQUEST["long"];
$sql_query = mysql_query($long);

       while($row = mysql_fetch_array($sql_query)){
		printf(''.$row["long"]."\xA");
       }
        
?>
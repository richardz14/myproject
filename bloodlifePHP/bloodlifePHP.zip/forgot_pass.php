<?php

//$server = "localhost";
//$user = "root";
//$pass = "";
//$database = "bloodlife_db";

$server = "sql208.byethost6.com";
$user = "b6_20129653";
$pass = "ap061581";
$database = "b6_20129653_bloodlife_db";

$conection = mysql_connect($server, $user, $pass);
mysql_select_db($database,$conection);

$recover = $_REQUEST["recover"];
mysql_query($recover);
    
        
?>
<?php

//$server = "localhost";
//$user = "root";
//$pass = "";
//$database = "bloodlife_db";

$server = "sql208.byethost6.com";
$user = "b6_20129653";
$pass = "ap061581";
$database = "b6_20129653_bloodlife_db";

$conection = mysql_connect($server, $user, $pass);
mysql_select_db($database,$conection);

$phone1 = $_REQUEST["phone1"];
$sql_query = mysql_query($phone1);

       while($row = mysql_fetch_array($sql_query)){
           //echo ''.$row["phone_number1"];
		     printf(''.$row["phone_number1"]."\xA");
       }
        
?>
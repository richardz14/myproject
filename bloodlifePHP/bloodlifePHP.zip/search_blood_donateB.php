<?php

//$server = "localhost";
//$user = "root";
//$pass = "";
//$database = "bloodlife_db";

$server = "sql208.byethost6.com";
$user = "b6_20129653";
$pass = "ap061581";
$database = "b6_20129653_bloodlife_db";

$conection = mysql_connect($server, $user, $pass);
mysql_select_db($database,$conection);

$donate_b = $_REQUEST["donate_b"];
$sql_query = mysql_query($donate_b);

       while($row = mysql_fetch_array($sql_query)){
           //echo ''.$row["donate_boolean"];
		    printf(''.$row["donate_boolean"]." (".$row["date_donated"].")"."\xA");
       }
        
?>